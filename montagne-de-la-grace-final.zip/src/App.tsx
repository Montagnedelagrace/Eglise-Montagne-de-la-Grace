
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AdminDashboard from './pages/AdminDashboard';
import Forms from './pages/Forms';
import Login from './pages/Login';

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/formulaires" element={<Forms />} />
    </Routes>
  </BrowserRouter>
);

export default App;
